const express = require('express');
const app = express();

const port = 8000;

// data base (JSON)


const studentss = [
  {
    id: 1,
    name: "Sameer",
    class: "Btexh"
  },
  {
    id: 2,
    name: "Sana",
    class: "Btech"
  }
]

// data read


app.listen(port, () =>  {
    console.log(`Server is running on port ${port}`);
})